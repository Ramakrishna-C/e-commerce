package com.example.inventory.category;

import org.springframework.stereotype.Service;

@Service
public class CategoryService {

}
